//
// Created by amichai on 27/12/18.
//

#include "Forwards.h"

double Forwards::alpha() {
    return 0.25;
}

double Forwards::beta() {
    return 1;
}

double Forwards::gama() {
    return 1;
}

char Forwards::getPlayerType() {
    return 'F';
}
