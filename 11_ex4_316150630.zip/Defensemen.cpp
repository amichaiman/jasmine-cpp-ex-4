//
// Created by amichai on 27/12/18.
//

#include "Defensemen.h"

double Defensemen::alpha() {
    return 0.05;
}

double Defensemen::beta() {
    return 0.1;
}

double Defensemen::gama() {
    return 0;
}

char Defensemen::getPlayerType() {
    return 'D';
}
